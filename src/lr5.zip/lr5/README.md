# Practice 5 (Computed Properties + Data Generation + Unit Testing) — InterSystems IRIS

## Task
1. Add an **always computed property** to one of the classes and implement a **getter** for it.  
2. Create code for **automatic data generation** for all classes.  
3. Create **Unit Tests** for class/classes with:
   - unique, required, constrained properties and relationship
   - and ensure all tests succeed:
     - test creation of the object
     - test unique/required/constrained properties
     - test behavior when deleting an object with many/children relationship
     - test deletion of the object

## Solution Theme
**3D Printer Farm** domain model based on the UML from previous labs.

## Computed Property
Class: `lr5.Printer`  
Property: `LocationLabel` (Calculated, ReadOnly)

It is computed from embedded `PhysicalLocation` (serial object):

- `RoomNumber`
- explaining environment.

Output format:
`Room <RoomNumber> / Shelf <ShelfIndex>`

Getter method:
`Method LocationLabelGet() As %String`

## Data Generation
Class: `lr5.DataGenerator`

- `Generate(techCount, printerCount, jobsPerPrinter)` creates:
  - technicians (`lr5.Technician`)
  - printers with embedded locations (`lr5.Printer` + `lr5.Location`)
  - print jobs as children of printers (`lr5.PrintJob`)
- Respects:
  - **unique**: `BadgeID`, `InventoryNumber`
  - **required** fields
  - **constraints**: `NozzleTemp` range

## Unit Testing
Class: `lr5.UnitTests` extends `%UnitTest.TestCase`

Test cases:
1. `Test01_CreateObjects` — create objects + check computed property output
2. `Test02_Constraints` — required/unique/constrained validations
3. `Test03_DeleteParentWithChildren` — delete printer and ensure jobs are deleted (Dependent=1)
4. `Test04_DeleteObject` — delete technician and verify it is gone

## How to Run (Docker)

### 1) Compile all LR5 classes
Inside IRIS terminal (`USER>`):

```objectscript
Do $System.OBJ.Load("/opt/irisapp/src/lr5/Device.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/Location.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/Technician.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/Printer.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/PrintJob.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/DataGenerator.cls","ck")
Do $System.OBJ.Load("/opt/irisapp/src/lr5/UnitTests.cls","ck")
```

### 2) Generate demo data (optional)
```objectscript
Do ##class(lr5.DataGenerator).Run()
```

### 3) Run unit tests
```objectscript
Do ##class(lr5.UnitTests).Run()
```

You should see that **all tests succeed**.

---
**Files:** `src/lr5/*.cls`
